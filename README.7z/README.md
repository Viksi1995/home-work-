# ** Bezrukavaya Viktoria **
manager
## ** Contact **

Dnipro , Ukraine
+380961297273
[viktoriabezrukavaa0@gmail.com](https://mail.google.com/mail/u/0/?tab=rm&ogbl#inbox) 
## ** Experience **
Alpha Dent (2021-2022)
manager
## ** Education **
Kharkiv National University. Beketova
(2015 -2018)